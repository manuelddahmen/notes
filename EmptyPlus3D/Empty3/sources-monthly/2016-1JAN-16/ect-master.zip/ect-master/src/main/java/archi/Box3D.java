package archi;

import info.emptycanvas.library.object.Matrix33;
import info.emptycanvas.library.object.Point3D;
import info.emptycanvas.library.object.Representable;
import info.emptycanvas.library.object.TRIObject;

/**
 * Created by manue on 03-09-15.
 */
public class Box3D extends Representable {
    private TRIObject to = new TRIObject();

    public Box3D(Point3D p1, Point3D p2, Matrix33 rot) {

    }
}
