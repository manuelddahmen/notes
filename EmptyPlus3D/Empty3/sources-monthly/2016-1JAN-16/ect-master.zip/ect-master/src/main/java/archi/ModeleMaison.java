package archi;

import info.emptycanvas.library.object.Scene;

/**
 * Created by manue on 03-09-15.
 */
public class ModeleMaison {
    private Scene scene;

    public void construct() {
        scene = new Scene();


    }
}
