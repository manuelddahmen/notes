/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package neurone;

/**
 *
 * @author Se7en
 */
public class NeuroneTypeTest extends Neurone
{

    @Override
    public double fonction(Neurone source) {
        return 0;
    }
    
}
