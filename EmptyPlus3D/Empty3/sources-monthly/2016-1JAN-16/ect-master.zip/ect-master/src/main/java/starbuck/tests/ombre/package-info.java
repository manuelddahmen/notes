/**
 * 
 */
/**
 * @author Atelier
 *
 */
package starbuck.tests.ombre;