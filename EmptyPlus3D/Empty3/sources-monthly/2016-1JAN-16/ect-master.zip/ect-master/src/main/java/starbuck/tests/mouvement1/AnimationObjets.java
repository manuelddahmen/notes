package starbuck.tests.mouvement1;

public class AnimationObjets {

}
