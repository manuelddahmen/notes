/**
 * 
 */
/**
 * @author Manuel
 *
 */
package triangles;