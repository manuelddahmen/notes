package tensionsuperf;

public class Force {

	public Force() {
		
	}

}
