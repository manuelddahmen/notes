
package film_1;

/**
 *
 * @author Se7en
 */
class PlasmaTexture {
    
}
