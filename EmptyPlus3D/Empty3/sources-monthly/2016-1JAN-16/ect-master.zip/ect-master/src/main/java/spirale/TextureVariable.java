/***
Global license : 

    Microsoft Public Licence
    
    author Manuel Dahmen <ibiiztera.it@gmail.com>

***/


package spirale;

/**
 *
 * @author Manuel Dahmen <ibiiztera.it@gmail.com>
 */
public class TextureVariable {

}
