package film_1;

import info.emptycanvas.library.object.Cube;
import info.emptycanvas.library.object.Matrix33;
import info.emptycanvas.library.object.SegmentDroite;
import info.emptycanvas.library.testing.TestObjet;

/**
 *
 * @author Se7en
 */
public class CubesQuiTombent extends TestObjet
{
    private Cube mouvement(SegmentDroite d, double pc, Matrix33 rot, double a, double b)
    {
        return null;
    }
    private void texturerPlasma(Cube c, PlasmaTexture text)
    {
    }
    @Override
    public void afterRenderFrame() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void finit() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void ginit() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void testScene() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void afterRender() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
