package mytests;
/*
import junit.framework.TestCase;

public class TestAll extends TestCase {
	public void testAll() {
/*
		TestCollection to =new TestCollection();
		
		to.displayResult(false);
		
		to.add(new ApartTestLoaderBin());
		to.add(new TestAnimationSphereInterieurBezierS());
		to.add(new TestAnimSIB());
		to.add(new TestBezier2D());
		to.add(new TestCamera());
		to.add(new TestCamera1());
		to.add(new TestChateau());
		to.add(new TestColline());
		to.add(new TestCollineIsometrique());
		to.add(new TestCollineIsometriqueStructure());
		to.add(new TestCollisee());
		to.add(new TestCube3D());
		to.add(new TestCubeTroue());
		to.add(new TestCubeTroueTriangles());
		to.add(new TestMartienSpheres());
		to.add(new TestMite());
		to.add(new TestNuageTriangles3D());
		//to.add(new TestPersoSTL());
		to.add(new TestPolygones());
		to.add(new TestSphere());
		to.add(new TestSphereInterieur());
		to.add(new TestSphereInterieurStructure());
		to.add(new TestTriangle());
		to.add(new TestTrianglePerspective());
		to.add(new TestTRIExtrusionGeneralisee());
		
		to.displayResult(false);
		to.run();
		
		assertTrue(true);
	}
	
}
*/