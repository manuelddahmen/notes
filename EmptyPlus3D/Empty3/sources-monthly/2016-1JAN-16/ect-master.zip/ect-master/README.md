# ect
Emptycanvas test packages

Classe testes pour le projet de manipluation d'objets 3D modélisés avec des primitives mathématiques.
Les tests peuvent être complexes mais en général ils visent à tester une seule fonctionnalité du programme à la fois.
Si les tests réussissent, on en refait encore quelques uns pour vérifier. Puis on dit que c'est "ok".

La classe de test n'utilisent pas de framework précompilés d'usage généraliste comme JUNit ou MckObj 
mais des méthodes propres à Emptycanvas. ON pourra douter de la fiabilité des tests et essayer d'améliorer 
la classe de tests en plus du framework lui-même.

